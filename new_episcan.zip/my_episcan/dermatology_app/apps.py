# dermatology_app/apps.py

from django.apps import AppConfig

class EpiscanAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dermatology_app'
# dermatology_app/urls.py
from django.urls import path, include
from django.urls import path
from .views import home, patient_list, skin_lesion_list

urlpatterns = [
    path('', home, name='patient-list'),
    path('patients/', patient_list, name='patient-list'),
    path('skin-lesions/', skin_lesion_list, name='skin-lesion-list'),
]

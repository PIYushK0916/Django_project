# dermatology_app/__init__.py

default_app_config = 'dermatology_app.apps.EpiscanAppConfig'

# dermatology_app/views.py

from django.shortcuts import render

def home(request):
    piyush = "BTCSD_2229"
    return render(request, 'dermatology_app/home.html', {'piyush': piyush})

def patient_list(request):
    return render(request, 'dermatology_app/patient_list.html')

def skin_lesion_list(request):
    return render(request, 'dermatology_app/skin_lesion_list.html')
